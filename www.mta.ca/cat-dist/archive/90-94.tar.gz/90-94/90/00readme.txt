This is 00readme.txt in pub/categories/90 at 
sun1.mta.ca (138.73.16.11)

The files in this directory each contain messages from one month
of the categories mailing list e.g. 90-10.txt is from October 1990.
Each message within a file begins with a header containing at minimum
"Date:"
The dates and subject lines of most messages are below:

Date         Subject

29-MAR     What are EECS meetings?
31-MAR     products of n-categories
31-MAR     noncommuting diagrams
3-APR      Change of phone number
6-APR      A reply to Vaughan
7-APR      new address etc
7-APR      Re:  new address etc
7-APR      Re:  new address etc
7-APR      Re: tensor product
9-APR      On (tensor) products of n-categories.
10-APR     More on tensor products of n-categories
10-APR     (simple?) question about 2-category-like structure
11-APR     Re: Reply to Question of Vaughn Pratt
11-APR     Re: (simple?) question about 2-category-like structure
18-APR     a hard-to-find paper
19-APR     corruption
23-MAY     Octoberfest
11-JUN     Category Theory for Computing Science:  Update
15-JUN     LICS List
25-JUN     Ordered Algebras
25-JUN     Re: Ordered Algebras
30-JUN     Bloom and Meseguer references
3-JUL      ordered algebras
5-JUL      re: ordered algebras
12-JUL     re: ordered algebras
14-JUL     Commutative Diagrams in La/TeX
19-JUL     Hubble Telescope
30-JUL     HSP Theorems
10-AUG     Dense frame maps
15-AUG     commutative diagrams
25-AUG     CT91
27-AUG     CT'91
3-OCT      Fixed Points in Synthetic Domain Theory
18-OCT     EECS '91
19-OCT     TTT-CTCS Corrections
28-OCT     TTT Corrections
1-NOV      two typos in Categories, Allegories
2-NOV      EECS '91
10-NOV     TTT-CTCS Corrections
14-NOV     Homotopy = homobject
14-NOV     homotopy = homobject
14-DEC     full internally complete sub-lccc-s
18-DEC     Re:  full internally complete sub-lccc-s
18-DEC     Bulgarian visas
26-DEC     CATEGORY THEORY 1991:  SECOND ANNOUNCEMENT
26-DEC     Re: full internally complete sub-lccc-s
26-DEC     Constructivity in Computer Science Conference
31-DEC     weak intensional identity types

File updated:
10 September 1991
