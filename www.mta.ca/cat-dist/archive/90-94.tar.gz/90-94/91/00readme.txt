This is readme.txt in /pub/categories/91 at 
sun1.mta.ca (138.73.16.11)

The files in this directory each contain messages from one month
of the categories mailing list e.g. 91-03.txt is from March 1991.
Each message within a file begins with a header containing at minimum
"Date:"
The dates and subject lines of most messages are below:

Date         Subject

7-JAN-1991   Concurrency and linear logic paper
9-JAN-1991   Renewal of Call for Papers
11-JAN-1991  Re: Bulgarian visas
17-JAN-1991  Event spaces abstract
29-JAN-1991  email list
30-JAN-1991  additions/corrections
31-JAN-1991  yet another list
4-FEB-1991   another correction
6-FEB-1991   list by ftp
17-FEB-1991  Abstract: Constructive complete distributivity
17-FEB-1991  Question on Tannaka-Krein categories
22-FEB-1991  Ross Street
23-FEB-1991  Availability of Casley's thesis by FTP
24-FEB-1991  Re:  Ross Street
25-FEB-1991  Re: addresses
25-FEB-1991  personal addresses
27-FEB-1991  Sydney Categories Address List
27-FEB-1991  e-mail address
1-MAR-1991   EECS '91 CANCELLED -- Cancellation telex for general distribution
10-MAR-1991  Correction
11-MAR-1991  Jobs at Macquarie
13-MAR-1991  Release 2.0
14-MAR-1991  Comments on Release 2.0
14-MAR-1991  Scott topologies
15-MAR-1991  Applications of Grothendieck topologies in computer science
16-MAR-1991  Re: Scott topologies
17-MAR-1991  Applications of Grothendieck topologies in computer science
18-MAR-1991  Material available from Sydney by anonymous ftp
19-MAR-1991  More references on sheaves in concurrency
19-MAR-1991  Re: Applications of Grothendieck topologies in computer science
21-MAR-1991  Re:  Applications of Grothendieck topologies in computer science
29-MAR-1991  Research position available
3-APR-1991   LICS'91 Program
9-APR-1991   LICS'91 Registration
10-APR-1991  FIRST ANNOUNCEMENT
10-APR-1991  CT91 reminder
12-APR-1991  algebras on graph sets
12-APR-1991  RE: algebras on graph sets
13-APR-1991  Re:  algebras on graph sets
15-APR-1991  question on set theory
15-APR-1991  Re: question on set theory
16-APR-1991  My question
16-APR-1991  question on set theory
16-APR-1991  question on set theory
16-APR-1991  Re: question on set theory
17-APR-1991  beth in TeX
17-APR-1991  A final answer from Leivant to my question
20-APR-1991  re: question on set theory
23-APR-1991  Categories of separated presheaves
23-APR-1991  separated presheaves
23-APR-1991  set theory question
23-APR-1991  Re: Categories of separated presheaves
24-APR-1991  Categorical view of loop invariants
25-APR-1991  Program of MWPL
25-APR-1991  Tex 3.0
25-APR-1991  Event spaces paper
26-APR-1991  Bug fix
26-APR-1991  Network Mail Message
29-APR-1991  Re: Categorical view of loop invariants (& diagrams)
6-MAY-1991   ? trees
8-MAY-1991   re supercalifragilistic trees
11-MAY-1991  Trakhtenbrot Symposium Program, June 10-12, Tel-Aviv
14-MAY-1991  CT91 Schedule
15-MAY-1991  addresses
17-MAY-1991  Network Mail Message
20-MAY-1991  Theor. Aspects of Software, Sendai, Japan, 9/24-27/91
21-MAY-1991  Constructivity symposium
22-MAY-1991  CATEGORY THEORY AND COMPUTER SCIENCE 91
24-MAY-1991  Kan extensions programs
24-MAY-1991  CT91 directions
24-MAY-1991  CTCS announcement
27-MAY-1991  email address for Hugo Volger?
6-JUN-1991   LFCS'92: 'Logic at Tver'
10-JUL-1991  non-abelian cohomology
10-JUL-1991  LICS'92 Preliminary Call
11-JUL-1991  RE: non-abelian cohomology
11-JUL-1991  A Question on Monoidal Categories
12-JUL-1991  Re: non-abelian cohomology
15-JUL-1991  T-Algebras in PLC
18-JUL-1991  Query on Topos of Labeled Trees
31-JUL-1991  New email address
7-AUG-1991   CTCS 91, last announcement
13-AUG-1991  Online bibliography for Information and Computation
14-AUG-1991  Logical Frameworks Workshop: Informal Proceedings
14-AUG-1991  Free categories
14-AUG-1991  Network Mail Message
17-AUG-1991  Re: Logical Frameworks Workshop: Informal Proceedings
17-AUG-1991  Re: free categories
21-AUG-1991  Query on initial algebras ...
21-AUG-1991  Finite Limit Theories
23-AUG-1991  Partial morphisms in toposes
26-AUG-1991  latest update to CTCS
27-AUG-1991  Online bibliography for Symposium on Logic in Computer Science
28-AUG-1991  Re:  Partial morphisms in toposes
29-AUG-1991  Re: Finite Limit Theories
3-SEP-1991   Re: Partial Morphisms in a Topos
5-SEP-1991   ftp on triples
6-SEP-1991   Review of CTCS
8-SEP-1991   Apology to David Murphy
9-SEP-1991   Index for papers at triples
9-SEP-1991   embar cats
10-SEP-1991  peejayeff functors
12-SEP-1991  PJF Functors
12-SEP-1991  PJF's contribution
13-SEP-1991  NEW ADDRESS/FTP SITE
17-SEP-1991  PJF on Barr on PJF
19-SEP-1991  Re: A diagram lemma
20-SEP-1991  Fred Linton's reply
20-SEP-1991  Re: A diagram lemma
20-SEP-1991  Re: A diagram lemma
21-SEP-1991  Re: A diagram lemma
24-SEP-1991  Re:  A diagram lemma
26-SEP-1991  Re:  A diagram lemma
26-SEP-1991  Re:  A diagram lemma
27-SEP-1991  Call for papers - CT91
1-OCT-1991   ftp on macc2.mta.ca
7-OCT-1991   Bi-Heyting algebras, toposes and modalities
7-OCT-1991   Paper by Cockett and Seely
7-OCT-1991   Parity Complexes
7-OCT-1991   The Category of Hilbert Spaces
16-OCT-1991  query
22-OCT-1991  Monograph: Category Theory for the Working Computer Scientist
22-OCT-1991  homotopy theory, but really ...
24-OCT-1991  RE: homotopy theory, but really ...
28-OCT-1991  omega-cats
30-OCT-1991  Re: omega-cats
31-OCT-1991  Re: omega-cats
5-NOV-1991   linear@cs.stanford.edu
8-NOV-1991   Urgent message to all category theorists
12-NOV-1991  We've been shafted again
13-NOV-1991  RE: We've been shafted again
14-NOV-1991  RE: We've been shafted again
14-NOV-1991  FTP archive at Imperial etc
15-NOV-1991  RE: We've been shafted again
15-NOV-1991  RE:FTP archive at Imperial etc
16-NOV-1991  RE: We've been shafted again
17-NOV-1991  NNO
17-NOV-1991  Are there French words for locales and frames
18-NOV-1991  RE: We've been shafted again
19-NOV-1991  Re: Are there French words for locales and frames
20-NOV-1991  Re: Are there French words for locales and frames
21-NOV-1991  Re: Are there French words for locales and frames
26-NOV-1991  Union Conference
1-DEC-1991   Two-sided proof nets with units
2-DEC-1991   Structures Directory Release 3.0
3-DEC-1991   LICS Database
6-DEC-1991   Imperial College archive and TeX fonts
10-DEC-1991  Book Ad.
14-DEC-1991  query,deformations
17-DEC-1991  Re: query,deformations
20-DEC-1991  database article by ftp

File updated:
2 January 1992
