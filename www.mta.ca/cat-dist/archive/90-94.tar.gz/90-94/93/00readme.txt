This is 00readme.txt in /pub/categories/93 at 
sun1.mta.ca (138.73.16.11)

The files in this directory each contain messages from one month
of the categories mailing list e.g. 93-03.txt is from March 1993.
Each message within a file begins with a header containing at minimum
"Date:"
The dates and subject lines of most messages are in the files
dir.jan-jun and dir.jul-dec in this directory.

File updated:
10 Jan 1994
